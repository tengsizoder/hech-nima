<?php
ob_start();
define("DB_SERVER","localhost"); 
define("DB_USERNAME","c1177_sfx"); 
define("DB_PASSWORD","Y1982O11K15"); 
define("DB_NAME","c1177_sfx");
$site_url = $_SERVER['HTTP_HOST'];
$connect = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
mysqli_set_charset($connect,"utf8mb4");
$bot = "SFXSMMBot";


$th = mysqli_query($connect,"SELECT * FROM `settings` WHERE id = 1");
$row = mysqli_fetch_assoc($th);
$theme = $row['site_theme'];
$style =$row['site_style'];
?>