<?php

// MySQLga ulanish
$connect = mysqli_connect("localhost", "c1177_sfx", "Y1982O11K15", "c1177_sfx");

// Xatolik bo'lsa
if (!$connect) {
    die("MySQL ulanmadi: " . mysqli_connect_error());
}

// Ustun mavjud yoki yo'qligini tekshirish
$checkColumn = mysqli_query($connect, "
    SHOW COLUMNS FROM `users` LIKE 'refnum'
");

// Agar ustun mavjud bo'lmasa — yaratamiz
if (mysqli_num_rows($checkColumn) == 0) {

    $addColumn = mysqli_query($connect, "
        ALTER TABLE `users` 
        ADD COLUMN `refnum` INT NOT NULL DEFAULT 0
    ");

    if ($addColumn) {
        echo "refnum ustuni muvaffaqiyatli yaratildi!";
    } else {
        echo "Xatolik: " . mysqli_error($connect);
    }

} else {
    echo "refnum ustuni allaqachon mavjud.";
}

?>
